var preloader = document.getElementById('loading');

function myFunction() {
    preloader.style.display = 'none';
}